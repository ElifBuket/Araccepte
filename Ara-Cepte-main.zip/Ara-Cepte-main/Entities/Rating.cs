﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracCepte.Entity.Entities
{
    public class Rating
    {
        public int Id { get; set; } // Rating ID
        public int SenderUserID { get; set; } //Sender's Rating ID
        public int ReceiverUserID { get; set; } // Receiver's Rating ID
        public int Point {  get; set; } //Point value
        public string Comment { get; set; } // Comment
    }
}
