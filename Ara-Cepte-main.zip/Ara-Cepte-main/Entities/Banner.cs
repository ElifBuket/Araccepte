﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracCepte.Entity.Entities
{
    public class Banner
    {
        public int BannerID { get; set; } // banner ID
        public string Title { get; set; } // Banner Title
        public string ImageUrl { get; set; } //banner Image
    }
}
